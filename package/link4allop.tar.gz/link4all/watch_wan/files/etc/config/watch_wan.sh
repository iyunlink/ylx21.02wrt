#!/bin/sh


watch_wan(){
        interface=`uci get watch_wan.@watch[$1].interface`
        time=`uci get watch_wan.@watch[$1].period`
        ip=`uci get watch_wan.@watch[$1].pinghost`
        [ ""x = "$ip"x ] && ip=223.5.5.5

        b_m=`uci get watch_wan.@watch[$1].b_m`
        [ ""x = "$b_m"x ] && b_m=10

        wan=`uci get network.$interface.ifname`
        [ ""x = "$wan"x ] && sleep 10 && return
        wan_m=`uci get network.$interface.metric `

        [ ""x = "$wan_m"x ] && wan_m=1

        if ping $ip -s1 -W1 -c1 -I $wan;then
                echo "------------------------ping ok   "
                Destination=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $1}'`
                Gateway=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $2}'`
                Genmask=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $3}'`
                Metric=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $5}'`

                if [ "$wan_m"x != "$Metric"x ];then
                        route del default gw $Gateway metric $Metric dev $wan
                        route add default gw $Gateway metric $wan_m dev $wan
                fi

                sleep $time
        else
                sleep $time
                if ping $ip -s1 -W1 -c1 -I $wan;then
                        echo "------------------------ping ok   "
                else
                        echo "------------------------ping faile   "
                        Destination=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $1}'`
                        Gateway=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $2}'`
                        Genmask=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $3}'`
                        Metric=`route -n|grep $wan|grep "0.0.0.0"|grep UG|awk '{print $5}'`

                        if [ "$wan_m"x == "$Metric"x ];then
                                route del default gw $Gateway metric $Metric dev $wan
                                route add default gw $Gateway metric $b_m dev $wan
                        fi
                fi

        fi

}

while true
do
        watch_wan 0

done

