#!/bin/sh /etc/rc.common

res=0

get_iccid(){
    local ethName iccid
    config_get ethName $1 ethName

    [ "$2" == "$ethName" ] && config_get iccid $1 iccid

    [ "NULL"x == "$iccid"x ] &&{
        res=0   
            return
        }
    [ ""x != "$iccid"x ] &&{
        res=1
            return
        }
}

get_metric(){
    local intface device metric 
    config_get device $1 device

    [ "$2" == "$device" ] && config_get metric $1 metric

    [ ""x != "$metric"x ] &&{
        [ $metric -gt 10 ] && {
                let metric-=10 
                config_set metric $1 $metric
            }
            res=$metric   
            return
        }
    [ ""x != "$metric"x ] &&{
        res=0
            return
        }
} 


get_ip(){
    local ip
    config_get ip $1 $2

    [ ""x != "$ip"x ] &&{
        res=$ip   
            return
        }
    [ ""x != "$metric"x ] &&{
        res=0
            return
        }
} 

set_route_on(){
    echo "this is set_route_on"
    uci set network.$1.metric=$3
    ifup $1
    multipath $2 on
} 

set_route_off(){
    local metric=$(($3 + 10))
    uci set network.$1.metric=$metric
    ifup $1

} 

reset_mode(){
    at_tool $2 -d $1
    echo "at_tool $2 -d $1"
} 



watch_lte(){

    local enable
    local atcmd tty tool netdevice
    local iccid=0
    local metric metric_tmp
    local dev_interface
    local ip
    config_get_bool enable $1 enable

    config_get atcmd $1 atcmd
    config_get tty $1 tty
    config_get tool $1 tool
    config_get netdevice $1 netdevice

    echo "------>enable:$enable"
    echo "------>atcmd:$atcmd"
    echo "------>tty:$tty"
    echo "------>tool:$tool"
    echo "------>netdevice:$netdevice"

#从/tmp/lte_info中获取插卡情况
[ "" != "$netdevice" ] && {
    config_load /tmp/lte_info
    config_foreach get_iccid lte_info $netdevice
    iccid=$res
    echo "---------------------->iccid:$iccid"
}

#从/etc/config/network中获取dev
[ "$netdevice" != "" ] &&{
    dev_interface=`uci show network|grep $netdevice|cut -d '.' -f2`
    echo "------------------------>dev_interface:$dev_interface"
}

#从/etc/config/network中获取metric
[ "" != "$netdevice" ] &&{
    config_load /etc/config/network
    config_foreach get_metric interface $netdevice $dev_interface
    metric=$res
    echo "------------------------>metric:$metric"
}

#从/etc/config/ping中获取ip
[ "" != "$dev_interface" ] &&{
    config_load /etc/config/ping
    config_foreach get_ip ping $dev_interface
    ip=$res
    echo "------------------------>ip:$ip"
}

#从route路由表中获取metric值
[ "$metric" != "" ] &&{
    metric_tmp=`uci get network.$dev_interface.metric`
    echo "------------------------>metric_tmp:$metric_tmp"
}


if ping $ip -s1 -W1 -c1 -I $netdevice > /tmp/ping;then
    echo "---ping ok!"
    ttl=`cat /tmp/ping |grep ttl |cut -d "=" -f3`
    echo "----------------->ttl:$ttl"
    [ 500 -gt $ttl ] && [ "$metric_tmp" != "$metric" ] && set_route_on $dev_interface $netdevice $metric

    [ 500 -lt $ttl ] && [ "$metric_tmp" == "$metric" ] && set_route_off $dev_interface $netdevice $metric
    [ 500 -lt $ttl ] && [ "" == "`multipath | grep "$netdevice "|grep deactivated`" ] && multipath $netdevice  off
else
    echo "---ping faile!"
    [ "$iccid" == "1" ] && [ "at" == "$tool" ] && reset_mode $tty $atcmd 
    [ "$metric" == "$metric_tmp" ] && set_route_off $dev_interface $netdevice $metric 
    [ "" == "`multipath | grep "$netdevice "|grep deactivated`" ] && multipath $netdevice  off
fi


echo "

"

}

while true
do
    config_load config4g
    config_foreach watch_lte 4G
    time=`uci get watch_lte.watch.time`
    sleep $time

done

